"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-16 md:py-24 lg:py-32">
      <div className="container flex flex-col items-center justify-between gap-8 md:flex-row">
        <div className="flex flex-col gap-6 max-w-[600px]">
          <h1 className="text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
            Bridging the <span className="text-primary">Mentorship Gap</span> Among Students
          </h1>
          <p className="text-lg text-muted-foreground md:text-xl">
            Connect with experienced seniors who can guide you through your academic journey,
            help you navigate course selection, internships, and provide valuable advice.
          </p>
          <div className="flex flex-col gap-4 sm:flex-row">
            <Button size="lg" asChild>
              <Link href="/register">Find a Mentor</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/register?role=mentor">Become a Mentor</Link>
            </Button>
          </div>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-primary"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span>Free to join</span>
            </div>
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-primary"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span>AI-powered matching</span>
            </div>
            <div className="flex items-center gap-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-5 w-5 text-primary"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <span>Growing community</span>
            </div>
          </div>
        </div>
        <div className="relative h-[400px] w-full max-w-[500px]">
          <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-violet-500/20 to-purple-500/20 blur-3xl"></div>
          <div className="relative h-full w-full rounded-lg border bg-card p-6 shadow-lg">
            <div className="grid grid-cols-2 gap-4 h-full">
              <div className="flex flex-col gap-4">
                <div className="h-24 rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Find the right mentor</h3>
                  <p className="text-xs text-muted-foreground">Based on your goals</p>
                </div>
                <div className="h-24 rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Schedule sessions</h3>
                  <p className="text-xs text-muted-foreground">1-on-1 guidance</p>
                </div>
                <div className="grow rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Track progress</h3>
                  <p className="text-xs text-muted-foreground">Achieve your goals</p>
                </div>
              </div>
              <div className="flex flex-col gap-4">
                <div className="grow rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Access resources</h3>
                  <p className="text-xs text-muted-foreground">Curated content</p>
                </div>
                <div className="h-24 rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Join group sessions</h3>
                  <p className="text-xs text-muted-foreground">Learn together</p>
                </div>
                <div className="h-24 rounded-md bg-accent p-4 flex flex-col justify-center">
                  <h3 className="font-medium">Get certified</h3>
                  <p className="text-xs text-muted-foreground">For mentors & mentees</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
