"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function CtaSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="rounded-lg bg-primary/10 p-8 md:p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 via-transparent to-purple-500/10"></div>
          <div className="relative z-10">
            <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold tracking-tight md:text-4xl mb-4">
                Ready to Experience the Power of Mentorship?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
                Join our growing community of mentors and mentees. Whether you're looking for guidance
                or want to share your knowledge, MentorMatch connects you with the right people.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" asChild>
                  <Link href="/register">Find a Mentor</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/register?role=mentor">Become a Mentor</Link>
                </Button>
              </div>
              <div className="mt-8 text-sm text-muted-foreground">
                <p>Free to join. No credit card required.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
