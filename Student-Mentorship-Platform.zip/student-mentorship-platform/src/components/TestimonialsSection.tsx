"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export function TestimonialsSection() {
  const testimonials = [
    {
      quote:
        "Finding a mentor through this platform changed my academic journey completely. My mentor helped me choose the right courses, prepare for internships, and build my confidence.",
      name: "Alex Chen",
      role: "Computer Science Junior",
      avatar: "AC",
    },
    {
      quote:
        "Being a mentor on this platform has been incredibly rewarding. It feels great to give back and help juniors navigate challenges that I once faced myself.",
      name: "Priya Sharma",
      role: "Engineering Senior, Mentor",
      avatar: "PS",
    },
    {
      quote:
        "The structured roadmaps provided by my mentor made a huge difference in my career planning. I now have a clear path to follow and goals to achieve.",
      name: "Marcus Johnson",
      role: "Business Student",
      avatar: "MJ",
    },
    {
      quote:
        "As someone who was hesitant to ask for help, this platform made it easy to connect with seniors who were genuinely interested in my growth.",
      name: "Sofia Rodriguez",
      role: "Psychology Sophomore",
      avatar: "SR",
    },
    {
      quote:
        "Our university partnered with this platform, and it has significantly improved the mentorship culture on campus. Students are more engaged and supported.",
      name: "Dr. James Wilson",
      role: "University Administrator",
      avatar: "JW",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-muted/50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            What Students Are Saying
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
            Hear from students who have experienced the power of mentorship on our platform.
          </p>
        </div>
        <Carousel className="w-full max-w-5xl mx-auto">
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3 pl-4">
                <div className="p-1">
                  <Card>
                    <CardContent className="flex flex-col gap-4 p-6">
                      <div className="relative">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-6 w-6 text-primary absolute -top-2 -left-2 opacity-30"
                        >
                          <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
                          <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" />
                        </svg>
                        <p className="text-muted-foreground relative pt-4">{testimonial.quote}</p>
                      </div>
                      <div className="flex items-center gap-4 mt-4">
                        <Avatar>
                          <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{testimonial.name}</p>
                          <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex" />
          <CarouselNext className="hidden md:flex" />
        </Carousel>
      </div>
    </section>
  );
}
