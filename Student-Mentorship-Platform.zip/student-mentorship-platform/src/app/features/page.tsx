import { Navbar } from "@/components/Navbar";
import { FeaturesSection } from "@/components/FeaturesSection";
import { CtaSection } from "@/components/CtaSection";
import { Footer } from "@/components/Footer";

export const metadata = {
  title: "Features | MentorMatch",
  description: "Explore the comprehensive features of our mentorship platform designed to connect students with mentors.",
};

export default function FeaturesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl mb-4">
              Platform Features
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Our platform offers a comprehensive set of features designed to make mentorship
              accessible, effective, and rewarding for both mentors and mentees.
            </p>
          </div>
        </div>
        <FeaturesSection />
        <div className="container py-8 md:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div className="bg-muted rounded-lg p-8">
              <h2 className="text-2xl font-semibold mb-6">For Mentees</h2>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">01</span>
                  <div>
                    <p className="font-medium">Personalized Mentor Matching</p>
                    <p className="text-sm text-muted-foreground">
                      Get matched with the right mentors based on your academic field, career goals, and personal interests.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">02</span>
                  <div>
                    <p className="font-medium">Direct Communication</p>
                    <p className="text-sm text-muted-foreground">
                      Connect with mentors through direct messaging, video calls, and scheduled one-on-one sessions.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">03</span>
                  <div>
                    <p className="font-medium">Resource Access</p>
                    <p className="text-sm text-muted-foreground">
                      Access a wealth of learning materials, roadmaps, and resources shared by experienced mentors.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">04</span>
                  <div>
                    <p className="font-medium">Progress Tracking</p>
                    <p className="text-sm text-muted-foreground">
                      Set personal goals, track your progress, and receive automated reminders for scheduled sessions.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">05</span>
                  <div>
                    <p className="font-medium">Community Forums</p>
                    <p className="text-sm text-muted-foreground">
                      Participate in group discussions, ask questions, and learn from the experiences of peers and mentors.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="bg-muted rounded-lg p-8">
              <h2 className="text-2xl font-semibold mb-6">For Mentors</h2>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">01</span>
                  <div>
                    <p className="font-medium">Impact Tracking</p>
                    <p className="text-sm text-muted-foreground">
                      See the direct impact of your mentorship through mentee progress metrics and feedback.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">02</span>
                  <div>
                    <p className="font-medium">Resource Sharing</p>
                    <p className="text-sm text-muted-foreground">
                      Create and share structured roadmaps, study materials, and resources with your mentees.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">03</span>
                  <div>
                    <p className="font-medium">Time Management</p>
                    <p className="text-sm text-muted-foreground">
                      Set your availability, schedule sessions, and manage your mentorship commitments efficiently.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">04</span>
                  <div>
                    <p className="font-medium">Recognition & Rewards</p>
                    <p className="text-sm text-muted-foreground">
                      Earn points, badges, and certificates for your mentorship contributions and achievements.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-xl font-bold text-primary">05</span>
                  <div>
                    <p className="font-medium">Mentor Network</p>
                    <p className="text-sm text-muted-foreground">
                      Connect with other mentors, share best practices, and collaborate on mentorship initiatives.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <CtaSection />
      </main>
      <Footer />
    </div>
  );
}
